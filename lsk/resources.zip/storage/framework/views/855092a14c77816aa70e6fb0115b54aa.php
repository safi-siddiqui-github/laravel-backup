<div class="flex flex-col gap-2">
    <div class="flex w-full flex-wrap items-center gap-2">
        <a
            href="<?php echo e(route('social.google.login')); ?>"
            class="flex min-w-fit flex-1 items-center justify-center gap-1.5 rounded border px-2 py-1.5 hover:outline"
        >
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.google', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-233043543-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <p class="font-medium tracking-tight">Continue with Google</p>
        </a>

        <a
            href="<?php echo e(route('social.github.login')); ?>"
            class="flex min-w-fit flex-1 items-center justify-center gap-1.5 rounded border px-2 py-1.5 hover:outline"
        >
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.github', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-233043543-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <p class="font-medium tracking-tight">Continue with Github</p>
        </a>
    </div>

    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['socialAuth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p
            x-transition
            class="text-red-500"
        >
            <?php echo e($message); ?>

        </p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH /var/www/html/resources/views/livewire/default/components/social-login.blade.php ENDPATH**/ ?>