<!-- Layout - resources/views/components/livewire/layout.blade.php -->
<?php if (isset($component)) { $__componentOriginal43c68fdf661e64877ad21a80d4c3676a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43c68fdf661e64877ad21a80d4c3676a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.livewire.layout','data' => ['title' => $title ?? null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('livewire.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title ?? null)]); ?>
    <!-- Header - resources/views/livewire/default/components/header.blade.php -->
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.components.header', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3813403956-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <!-- Children / Slot -->
    <?php echo e($slot); ?>


    <!-- resources/views/livewire/default/components/notification-bar.blade.php -->
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.components.notification-bar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3813403956-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43c68fdf661e64877ad21a80d4c3676a)): ?>
<?php $attributes = $__attributesOriginal43c68fdf661e64877ad21a80d4c3676a; ?>
<?php unset($__attributesOriginal43c68fdf661e64877ad21a80d4c3676a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43c68fdf661e64877ad21a80d4c3676a)): ?>
<?php $component = $__componentOriginal43c68fdf661e64877ad21a80d4c3676a; ?>
<?php unset($__componentOriginal43c68fdf661e64877ad21a80d4c3676a); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/livewire/default/layout/app.blade.php ENDPATH**/ ?>