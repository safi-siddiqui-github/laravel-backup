<?php if (isset($component)) { $__componentOriginala90006d849a72b672bc5347fd7ab5556 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala90006d849a72b672bc5347fd7ab5556 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.default.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('default.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col gap-4 p-4">
        <div class="flex flex-col gap-1">
            <h2 class="text-xl font-medium">Safi Siddiqui</h2>
            <p class="">Livewire, React, Vue, React Native</p>
        </div>
        <hr />

        

        <div class="item-start flex flex-col">
            <h2 class="font-medium">Livewire Apps</h2>
            <a href="<?php echo e(route('livewire.crm.home')); ?>" class="">CRM App</a>
        </div>

        <div class="item-start flex flex-col">
            <h2 class="font-medium">React Apps</h2>
            <a href="<?php echo e(route('react.crm.home')); ?>" class="">CRM App</a>
        </div>

        <div class="item-start flex flex-col">
            <h2 class="font-medium">Vue Apps</h2>
            <a href="<?php echo e(route('vue.crm.home')); ?>" class="">CRM App</a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala90006d849a72b672bc5347fd7ab5556)): ?>
<?php $attributes = $__attributesOriginala90006d849a72b672bc5347fd7ab5556; ?>
<?php unset($__attributesOriginala90006d849a72b672bc5347fd7ab5556); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala90006d849a72b672bc5347fd7ab5556)): ?>
<?php $component = $__componentOriginala90006d849a72b672bc5347fd7ab5556; ?>
<?php unset($__componentOriginala90006d849a72b672bc5347fd7ab5556); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>