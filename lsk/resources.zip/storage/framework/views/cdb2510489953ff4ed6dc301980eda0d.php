<?php

use Livewire\Volt\Actions;
use Livewire\Volt\CompileContext;
use Livewire\Volt\Contracts\Compiled;
use Livewire\Volt\Component;

new class extends Component implements Livewire\Volt\Contracts\FunctionalComponent
{
    public static CompileContext $__context;

    use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

    public $username;

    public $email;

    public $password;

    public $password_confirmation;

    public $showPassword;

    public $passwordType;

    public $showPasswordConfirmation;

    public $passwordConfirmationType;

    public function mount()
    {
        (new Actions\InitializeState)->execute(static::$__context, $this, get_defined_vars());

        (new Actions\CallHook('mount'))->execute(static::$__context, $this, get_defined_vars());
    }

    public function register()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('register'))->execute(...$arguments);
    }

    public function togglePassword()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('togglePassword'))->execute(...$arguments);
    }

    public function togglePasswordConfirmation()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('togglePasswordConfirmation'))->execute(...$arguments);
    }

    protected function rules()
    {
        return (new Actions\ReturnRules)->execute(static::$__context, $this, []);
    }

};