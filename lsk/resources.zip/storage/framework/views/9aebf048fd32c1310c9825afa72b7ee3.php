<?php

use App\Enums\NotifyBarEnum;
use App\Http\Requests\AuthRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

?>

<header class="flex flex-wrap items-center justify-center gap-4 border-b border-slate-500 py-1 pr-4 sm:justify-between sm:py-0">
    <div class="flex flex-wrap items-center justify-center">
        <a
            wire:navigate
            href="<?php echo e(route('livewire.home')); ?>"
            class="flex gap-1 bg-black p-2 text-white md:px-6 dark:bg-white dark:text-black"
        >
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.laravel', ['class' => 'size-7']);

$__html = app('livewire')->mount($__name, $__params, 'lw-896998808-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <span class="text-lg font-medium">Livewire</span>
        </a>
        <a
            wire:navigate
            href="<?php echo e(route('react.home')); ?>"
            class="flex gap-1 p-2 md:px-6"
        >
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.react', ['class' => 'size-7']);

$__html = app('livewire')->mount($__name, $__params, 'lw-896998808-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <span class="text-lg font-medium">React</span>
        </a>
        <a
            wire:navigate
            href="<?php echo e(route('vue.home')); ?>"
            class="flex gap-1 p-2 md:px-6"
        >
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.vue', ['class' => 'size-7']);

$__html = app('livewire')->mount($__name, $__params, 'lw-896998808-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <span class="text-lg font-medium">Vue</span>
        </a>
    </div>

    <div class="flex flex-wrap items-center gap-2">
        <!--[if BLOCK]><![endif]--><?php if(auth()->guard()->check()): ?>
            <a
                wire:navigate
                href="<?php echo e(route('livewire.profile.overview')); ?>"
                class="flex min-w-fit items-center gap-1 px-2 py-1"
            >
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.user', ['class' => 'size-6']);

$__html = app('livewire')->mount($__name, $__params, 'lw-896998808-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <p class="font-medium">
                    <?php echo e($this->username); ?>

                </p>
            </a>

            <button
                type="button"
                wire:click="logout"
                class="flex min-w-fit items-center gap-1 rounded px-2 py-1"
            >
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.sign-out', ['class' => 'size-6']);

$__html = app('livewire')->mount($__name, $__params, 'lw-896998808-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <span class="font-medium">Logout</span>
            </button>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <!--[if BLOCK]><![endif]--><?php if(auth()->guard()->guest()): ?>
            <a
                wire:navigate
                href="<?php echo e(route('livewire.login')); ?>"
                class="flex min-w-fit items-center gap-1 px-2 py-1"
            >
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.sign-in', ['class' => 'size-6']);

$__html = app('livewire')->mount($__name, $__params, 'lw-896998808-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <p class="font-medium">Login</p>
            </a>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.components.mode-toggler', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-896998808-6', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
</header><?php /**PATH /var/www/html/resources/views/livewire/default/components/header.blade.php ENDPATH**/ ?>