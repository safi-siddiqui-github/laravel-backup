<div>
    Livewire CRM APP
    <button wire:click="add">Do this</button>
</div><?php /**PATH /var/www/html/resources/views/livewire/crm/pages/home.blade.php ENDPATH**/ ?>