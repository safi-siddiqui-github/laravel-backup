<?php

use App\Http\Requests\Auth\PasswordEmailRequest;
use App\Http\Requests\Auth\PasswordResetRequest;
use Illuminate\Support\Facades\Auth;

?>

<div class="flex flex-col gap-6 px-4 py-8">
    <div class="flex flex-col items-center gap-2">
        <h2 class="text-2xl">PASSWORD UPDATE</h2>

        <p class="flex flex-wrap items-center gap-1">
            <span class="tracking-tight">Make secure, strong</span>
            <span class="font-medium">Password</span>
        </p>
    </div>

    <form wire:submit="passwordReset" class="flex w-full flex-col gap-4">
        <div class="flex flex-col gap-1">
            <label for="email" class="w-fit font-medium">Email</label>

            <input
                type="text"
                value="<?php echo e($this->email); ?>"
                disabled="true"
                class="w-full rounded border px-2 py-1"
            />
        </div>

        <div class="flex flex-col gap-1">
            <label for="pin" class="w-fit font-medium">Pin Code</label>

            <input
                wire:model="pin"
                id="pin"
                type="text"
                placeholder="0000"
                class="w-full rounded border px-2 py-1"
            />

            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p wire:transition class="text-red-500">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="group flex flex-col gap-1">
            <label for="password" class="w-fit font-medium">Password</label>

            <div
                class="flex rounded border px-2 py-1 group-focus-within:outline"
            >
                <input
                    wire:model="password"
                    id="password"
                    type="<?php echo e($passwordType); ?>"
                    placeholder="**********"
                    class="flex-1 outline-none"
                    autocomplete="new-password"
                />

                <button
                    class="outline-none"
                    type="button"
                    wire:click="togglePassword"
                >
                    <!--[if BLOCK]><![endif]--><?php if(! $showPassword): ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.eye-slash', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1300316597-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php else: ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.eye', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1300316597-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </button>
            </div>

            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p wire:transition class="text-red-500">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="group flex flex-col gap-1">
            <label for="password_confirmation" class="w-fit font-medium">
                Password Confirmation
            </label>

            <div
                class="flex rounded border px-2 py-1 group-focus-within:outline"
            >
                <input
                    wire:model="password_confirmation"
                    id="password_confirmation"
                    type="<?php echo e($passwordConfirmationType); ?>"
                    placeholder="**********"
                    class="flex-1 outline-none"
                />

                <button
                    class="outline-none"
                    type="button"
                    wire:click="togglePasswordConfirmation"
                >
                    <!--[if BLOCK]><![endif]--><?php if(! $showPasswordConfirmation): ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.eye-slash', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1300316597-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php else: ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.eye', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1300316597-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </button>
            </div>

            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p wire:transition class="text-red-500">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <button type="submit" class="rounded border py-1 font-medium">
            Update Password
        </button>
    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/default/pages/password-reset.blade.php ENDPATH**/ ?>