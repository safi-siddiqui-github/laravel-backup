<?php

use App\Http\Requests\Auth\LoginRequest;

?>

<div class="flex flex-col gap-6 px-4 py-8">
    <div class="flex flex-col items-center gap-2">
        <h2 class="text-4xl">LOGIN</h2>

        <a
            href="<?php echo e(route('livewire.register')); ?>"
            class="flex flex-wrap items-center gap-1"
            wire:navigate
        >
            <span class="tracking-tight">Create your new account?</span>
            <span class="font-medium">Sign Up</span>
        </a>
    </div>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.components.social-login', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1004078777-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <form wire:submit="login" class="flex w-full flex-col gap-4">
        <div class="flex flex-col gap-1">
            <label for="email" class="w-fit font-medium">Email</label>

            <input
                wire:model="email"
                id="email"
                type="text"
                placeholder="safi@gmail.com"
                autocomplete="on"
                class="w-full rounded border px-2 py-1"
            />

            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p wire:transition class="text-red-500">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="group flex flex-col gap-1">
            <div class="flex items-center justify-between">
                <label for="password" class="font-medium">Password</label>

                <a
                    href="<?php echo e(route('livewire.password.request')); ?>"
                    class="font-medium"
                >
                    Forgot Password?
                </a>
            </div>

            <div
                class="flex rounded border px-2 py-1 group-focus-within:outline"
            >
                <input
                    wire:model="password"
                    id="password"
                    type="<?php echo e($passwordType); ?>"
                    placeholder="**********"
                    autocomplete="true"
                    class="flex-1 outline-none"
                />

                <button
                    class="outline-none"
                    type="button"
                    wire:click="togglePassword"
                >
                    <!--[if BLOCK]><![endif]--><?php if(! $showPassword): ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.eye-slash', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1004078777-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php else: ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.eye', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1004078777-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </button>
            </div>

            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p wire:transition class="text-red-500">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="flex w-fit cursor-pointer items-center gap-2">
            <input
                id="remember"
                type="checkbox"
                wire:model="remember"
                class="size-4"
            />

            <label for="remember" class="font-medium">Remember Me</label>
        </div>

        <button type="submit" class="rounded border py-1 font-medium">
            Sign In
        </button>
    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/default/pages/login.blade.php ENDPATH**/ ?>