<div
    class="flex items-center justify-center"
    x-data="{
        darkMode: $wire.darkMode,
        init() {
            if (
                localStorage.theme === 'dark' ||
                (! ('theme' in localStorage) &&
                    window.matchMedia('(prefers-color-scheme: dark)').matches)
            ) {
                darkMode = true
            }
        },
    }"
    x-init="
        $watch('darkMode', (value) => {
            if (value) {
                // body selector
                document.querySelector('#light-dak-mode').classList.add('dark')
                // documentElement is html
                //document.documentElement.classList.add('dark');
                localStorage.setItem('theme', 'dark')
            } else {
                document.querySelector('#light-dak-mode').classList.remove('dark')
                // document.documentElement.classList.remove('dark');
                localStorage.setItem('theme', 'light')
            }
            $wire.toggleDarkMode()
            //window.location.reload();
        })
    "
>
    <button
        @click="darkMode=!darkMode"
        type="button"
        class="flex w-12 items-center gap-1 rounded-full border px-1 py-0.5"
        :class="darkMode ? 'justify-end' : 'justify-start'"
    >
        <span x-show="darkMode">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.moon', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-994207380-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </span>
        <span x-show="!darkMode">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.sun', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-994207380-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </span>
    </button>
</div><?php /**PATH /var/www/html/resources/views/livewire/default/components/mode-toggler.blade.php ENDPATH**/ ?>