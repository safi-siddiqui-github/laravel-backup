<?php

use App\Enums\NotifyBarEnum;
use App\Http\Requests\Auth\RegisterRequest;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Auth;

?>

<div class="flex flex-col gap-6 px-4 py-8">
    <div class="flex flex-col items-center gap-2">
        <h2 class="text-4xl">REGISTER</h2>

        <a
            href="<?php echo e(route('livewire.login')); ?>"
            class="flex flex-wrap items-center gap-1"
            wire:navigate
        >
            <span class="tracking-tight">Already have an account?</span>
            <span class="font-medium">Sign In</span>
        </a>
    </div>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.components.social-login', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2697880792-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <form wire:submit="register" class="flex w-full flex-col gap-4">
        <div class="flex flex-col gap-1">
            <label for="username" class="w-fit font-medium">Username</label>

            <input
                wire:model="username"
                id="username"
                type="text"
                placeholder="safi.siddiqui.1"
                autocomplete="on"
                class="w-full rounded border px-2 py-1"
            />

            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p wire:transition class="text-red-500">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="flex flex-col gap-1">
            <label for="email" class="w-fit font-medium">Email</label>

            <input
                wire:model="email"
                id="email"
                type="text"
                placeholder="safi@gmail.com"
                autocomplete="on"
                class="w-full rounded border px-2 py-1"
            />

            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p wire:transition class="text-red-500">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="group flex flex-col gap-1">
            <label for="password" class="w-fit font-medium">Password</label>

            <div
                class="flex rounded border px-2 py-1 group-focus-within:outline"
            >
                <input
                    wire:model="password"
                    id="password"
                    type="<?php echo e($passwordType); ?>"
                    placeholder="**********"
                    class="flex-1 outline-none"
                    autocomplete="new-password"
                />

                <button
                    class="outline-none"
                    type="button"
                    wire:click="togglePassword"
                >
                    <!--[if BLOCK]><![endif]--><?php if(! $showPassword): ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.eye-slash', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2697880792-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php else: ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.eye', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2697880792-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </button>
            </div>

            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p wire:transition class="text-red-500">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="group flex flex-col gap-1">
            <label for="password_confirmation" class="w-fit font-medium">
                Password Confirmation
            </label>

            <div
                class="flex rounded border px-2 py-1 group-focus-within:outline"
            >
                <input
                    wire:model="password_confirmation"
                    id="password_confirmation"
                    type="<?php echo e($passwordConfirmationType); ?>"
                    placeholder="**********"
                    class="flex-1 outline-none"
                />

                <button
                    class="outline-none"
                    type="button"
                    wire:click="togglePasswordConfirmation"
                >
                    <!--[if BLOCK]><![endif]--><?php if(! $showPasswordConfirmation): ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.eye-slash', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2697880792-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php else: ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.eye', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2697880792-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </button>
            </div>

            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p wire:transition class="text-red-500">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <button type="submit" class="rounded border py-1 font-medium">
            Sign Up
        </button>
    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/default/pages/register.blade.php ENDPATH**/ ?>