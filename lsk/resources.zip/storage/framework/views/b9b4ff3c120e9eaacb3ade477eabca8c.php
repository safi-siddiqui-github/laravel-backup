<?php

use Livewire\Volt\Actions;
use Livewire\Volt\CompileContext;
use Livewire\Volt\Contracts\Compiled;
use Livewire\Volt\Component;

new class extends Component implements Livewire\Volt\Contracts\FunctionalComponent
{
    public static CompileContext $__context;

    use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

    public $status;

    public function mount()
    {
        (new Actions\InitializeState)->execute(static::$__context, $this, get_defined_vars());

        (new Actions\CallHook('mount'))->execute(static::$__context, $this, get_defined_vars());
    }

    #[\Livewire\Attributes\Computed()]
    public function title()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('title'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function message()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('message'))->execute(...$arguments);
    }

    public function removeBar()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('removeBar'))->execute(...$arguments);
    }

};