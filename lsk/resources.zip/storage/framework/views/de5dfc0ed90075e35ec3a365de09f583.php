<!-- Layout - resources/views/components/livewire/layout.blade.php -->
<?php if (isset($component)) { $__componentOriginal43c68fdf661e64877ad21a80d4c3676a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43c68fdf661e64877ad21a80d4c3676a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.livewire.layout','data' => ['title' => $title ?? null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('livewire.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title ?? null)]); ?>
    <!--  -->
    <!-- Auth Header -->
    <div class="flex h-screen min-h-fit items-center justify-center overflow-y-auto">
        <div
            class="flex w-full flex-col divide-y-1 divide-slate-300 overflow-hidden sm:max-w-lg sm:rounded-lg sm:border sm:border-slate-300 sm:shadow"
        >
            <div class="flex flex-wrap">
                <a
                    wire:navigate
                    href="<?php echo e(route('livewire.login')); ?>"
                    class="flex flex-1 items-center justify-center gap-1 bg-black text-white dark:bg-white dark:text-black"
                >
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.laravel', ['class' => 'size-7']);

$__html = app('livewire')->mount($__name, $__params, 'lw-1501484062-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <p class="text-lg">Livewire</p>
                </a>
                <a
                    href="<?php echo e(route('react.login')); ?>"
                    class="flex flex-1 items-center justify-center gap-1 p-2"
                >
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.react', ['class' => 'size-7']);

$__html = app('livewire')->mount($__name, $__params, 'lw-1501484062-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <p class="text-lg">React</p>
                </a>

                <a
                    href="<?php echo e(route('vue.login')); ?>"
                    class="flex flex-1 items-center justify-center gap-1 p-2"
                >
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.vue', ['class' => 'size-7']);

$__html = app('livewire')->mount($__name, $__params, 'lw-1501484062-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <p class="text-lg">Vue</p>
                </a>
            </div>

            <!-- Children / Slot -->
            <?php echo e($slot); ?>

        </div>
    </div>

    <!-- resources/views/livewire/default/components/notification-bar.blade.php -->
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.components.notification-bar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1501484062-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43c68fdf661e64877ad21a80d4c3676a)): ?>
<?php $attributes = $__attributesOriginal43c68fdf661e64877ad21a80d4c3676a; ?>
<?php unset($__attributesOriginal43c68fdf661e64877ad21a80d4c3676a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43c68fdf661e64877ad21a80d4c3676a)): ?>
<?php $component = $__componentOriginal43c68fdf661e64877ad21a80d4c3676a; ?>
<?php unset($__componentOriginal43c68fdf661e64877ad21a80d4c3676a); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/livewire/default/layout/auth.blade.php ENDPATH**/ ?>