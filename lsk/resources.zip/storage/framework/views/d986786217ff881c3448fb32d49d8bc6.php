<?php

use App\Enums\NotifyBarEnum;
use App\Http\Requests\Auth\EmailVerificationRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

?>

<div class="flex flex-col gap-6 px-4 py-8">
    <div class="flex flex-col items-center gap-2">
        <h2 class="text-2xl">EMAIL VERIFICATION</h2>

        <button
            type="button"
            class="flex flex-wrap items-center gap-1 outline-none hover:underline"
        >
            <span class="tracking-tight">Get verfication Email?</span>
            <span class="font-medium">Resend</span>
        </button>
    </div>

    <form wire:submit="emailVerification" class="flex w-full flex-col gap-4">
        <div class="flex flex-col gap-1">
            <label for="email" class="w-fit font-medium">Email</label>

            <input
                value="<?php echo e($user->email); ?>"
                disabled="true"
                class="w-full rounded border px-2 py-1"
            />
        </div>

        <div class="flex flex-col gap-1">
            <label for="pin" class="w-fit font-medium">Pin Code</label>

            <input
                wire:model="pin"
                id="pin"
                type="text"
                placeholder="0000"
                class="w-full rounded border px-2 py-1"
            />

            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p wire:transition class="text-red-500">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <button type="submit" class="rounded border py-1 font-medium">
            Verify Email
        </button>
    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/default/pages/verification-notice.blade.php ENDPATH**/ ?>