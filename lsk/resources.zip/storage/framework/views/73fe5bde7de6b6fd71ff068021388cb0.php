<div class="flex flex-col gap-4 p-4">
    <div class="flex flex-col">
        <h2 class="text-2xl font-medium">Livewire Home</h2>
    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/default/pages/home/index.blade.php ENDPATH**/ ?>