<?php

use App\Enums\NotifyBarEnum;

?>

<div class="fixed right-0 bottom-0 w-full">
    <div
        class="flex flex-col items-end p-2"
        x-data="{
            status: $wire.status,
            removeStatus() {
                this.status = false
            },
        }"
        x-init="
            $watch('status', (value) => {
                if (! value) {
                    $wire.removeBar()
                }
            })
        "
    >
        <div
            wire:transition
            x-init="
                setTimeout(() => {
                    removeStatus()
                }, 5000)
            "
            class="flex w-full max-w-80 rounded border p-2 sm:w-80"
            :class="status ? '' : 'hidden'"
        >
            <button class="flex cursor-default items-center justify-center px-2">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.check', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-661233645-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </button>

            <div class="flex flex-1 flex-col">
                <p class="">
                    <?php echo e($this->title); ?>

                </p>

                <p class="text-xs">
                    <?php echo e($this->message); ?>

                </p>
            </div>

            <button
                @click="status=!status"
                type="button"
                class="flex items-center justify-center px-2"
            >
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.trash', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-661233645-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </button>
        </div>
    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/default/components/notification-bar.blade.php ENDPATH**/ ?>