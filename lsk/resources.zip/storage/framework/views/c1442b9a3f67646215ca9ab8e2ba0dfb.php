<?php

use App\Http\Requests\AuthRequest;
use Illuminate\Validation\ValidationException;

?>

<div class="flex flex-col gap-6 px-4 py-8">
    <div class="flex flex-col items-center gap-2">
        <h2 class="text-2xl">PASSWORD RESET</h2>

        <p class="flex flex-wrap items-center gap-1">
            <span class="tracking-tight">Make secure, strong</span>
            <span class="font-medium">Password</span>
        </p>
    </div>

    <form
        wire:submit="submitForm"
        class="flex w-full flex-col gap-4"
    >
        <div class="flex flex-col gap-1">
            <label
                for="email"
                class="w-fit font-medium"
            >
                Email
            </label>

            <input
                wire:model="email"
                id="email"
                type="text"
                placeholder="safi@gmail.com"
                autocomplete="on"
                class="w-full rounded border px-2 py-1"
            />

            <p
                x-show="$wire.errors?.email"
                x-transition
                x-text="$wire.errors?.email?.[0]"
                class="text-red-500"
            ></p>
        </div>

        <button
            type="submit"
            class="rounded border py-1 font-medium"
        >
            Request Email
        </button>
    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/default/pages/auth/password-request.blade.php ENDPATH**/ ?>