<?php

use App\Http\Requests\AuthRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

?>

<div class="flex flex-col gap-4 p-4">
    <img
        src="<?php echo e($user->avatar); ?>"
        alt="<?php echo e($user->name); ?>"
        class="object-conver h-32 w-32 rounded"
    />

    <div class="flex flex-col">
        <h2 class="text-2xl font-medium"><?php echo e($user->name); ?></h2>
        <p class="tracking-tight"><?php echo e($user->email); ?></p>
        <p class="tracking-tight">&#64;<?php echo e($user->username); ?></p>
    </div>

    <div class="flex flex-col gap-2">
        <p class="text-lg font-medium">Social Profiles</p>

        <div class="flex items-center gap-2">
            <div class="flex items-center gap-1">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.github', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1451789379-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <p class="">Github</p>
            </div>

            <div class="flex items-center gap-1">
                <!--[if BLOCK]><![endif]--><?php if($this->socialProfileStatus['github']): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.check', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1451789379-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <p class="">Connected</p>
                <?php else: ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.important', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1451789379-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <p class="">Disconnected</p>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <div class="flex items-center gap-2">
            <div class="flex items-center gap-1">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.google', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1451789379-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <p class="">Google</p>
            </div>

            <div class="flex items-center gap-1">
                <!--[if BLOCK]><![endif]--><?php if($this->socialProfileStatus['google']): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.check', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1451789379-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <p class="">Connected</p>
                <?php else: ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.important', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1451789379-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <p class="">Disconnected</p>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>

    <div class="flex flex-col items-start gap-2">
        <p class="text-lg font-medium">Delete Profile</p>

        <button
            wire:click="deleteUser"
            type="button"
            class="flex gap-1 rounded border px-2 py-1 hover:border-red-500 hover:text-red-500 hover:outline-red-500"
        >
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.trash', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1451789379-6', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <span class="">Delete</span>
        </button>
    </div>
</div><?php /**PATH /var/www/html/resources/views/livewire/default/pages/profile/index.blade.php ENDPATH**/ ?>