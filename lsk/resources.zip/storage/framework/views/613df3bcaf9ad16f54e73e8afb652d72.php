<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.layout.app', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3647529275-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php echo e($slot); ?>

</livewire:default.layout.app><?php /**PATH /var/www/html/resources/views/livewire/crm/layouts/app-layout.blade.php ENDPATH**/ ?>