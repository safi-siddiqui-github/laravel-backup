<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e($title ?? 'Livewire'); ?></title>

    <!-- Fonts -->
    

    <!-- Styles / Scripts -->
    <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php else: ?>
    <?php endif; ?>
</head>

<body
    id="light-dak-mode"
    class="antialiased text-sm text-black bg-white dark:bg-black dark:text-white relative <?php echo e(session('darkMode') ? 'dark' : ''); ?>">

    <?php echo e($slot); ?>


</body>

</html><?php /**PATH /var/www/html/resources/views/components/livewire/layout.blade.php ENDPATH**/ ?>