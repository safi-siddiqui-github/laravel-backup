<?php

use App\Http\Requests\Auth\PasswordEmailRequest;
use Illuminate\Support\Facades\Auth;

?>

<div class="flex flex-col gap-6 px-4 py-8">
    <div class="flex flex-col items-center gap-2">
        <h2 class="text-2xl">PASSWORD RESET</h2>

        <button
            type="button"
            class="flex flex-wrap items-center gap-1 outline-none hover:underline"
        >
            <span class="tracking-tight">Get password reset email?</span>
            <span class="font-medium">Resend</span>
        </button>
    </div>

    <form wire:submit="passwordEmail" class="flex w-full flex-col gap-4">
        <div class="flex flex-col gap-1">
            <label for="email" class="w-fit font-medium">Email</label>

            <input
                wire:model="email"
                id="email"
                type="text"
                placeholder="safi@gmail.com"
                autocomplete="on"
                class="w-full rounded border px-2 py-1"
            />

            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p wire:transition class="text-red-500">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <button type="submit" class="rounded border py-1 font-medium">
            Request Email
        </button>
    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/default/pages/password-request.blade.php ENDPATH**/ ?>