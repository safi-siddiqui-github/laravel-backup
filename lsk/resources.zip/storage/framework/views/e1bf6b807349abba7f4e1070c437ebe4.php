<?php

use App\Enums\NotifyBarEnum;
use App\Http\Requests\AuthRequest;
use Illuminate\Validation\ValidationException;

?>

<div class="flex flex-col gap-6 px-4 py-8">
    <div class="flex flex-col items-center gap-2">
        <h2 class="text-2xl">EMAIL VERIFICATION</h2>

        <button
            wire:click="resendPin"
            type="button"
            class="flex flex-wrap items-center gap-1 outline-none hover:underline"
        >
            <span class="tracking-tight">Get verfication Email?</span>
            <span class="font-medium">Resend</span>
        </button>
    </div>

    <form
        wire:submit="submitForm"
        class="flex w-full flex-col gap-4"
    >
        <div class="flex flex-col gap-1">
            <label
                for="email"
                class="w-fit font-medium"
            >
                Email
            </label>

            <input
                value="<?php echo e($this->email); ?>"
                disabled="true"
                type="text"
                class="w-full rounded border px-2 py-1"
            />

            <p
                x-show="$wire.errors?.email"
                x-transition
                x-text="$wire.errors?.email?.[0]"
                class="text-red-500"
            ></p>
        </div>

        <div class="flex flex-col gap-1">
            <label
                for="pin"
                class="w-fit font-medium"
            >
                Pin Code
            </label>

            <input
                wire:model="pin"
                id="pin"
                type="text"
                placeholder="0000"
                class="w-full rounded border px-2 py-1"
            />

            <p
                x-show="$wire.errors?.pin"
                x-transition
                x-text="$wire.errors?.pin?.[0]"
                class="text-red-500"
            ></p>
        </div>

        <button
            type="submit"
            class="relative flex items-center justify-center gap-2 rounded border py-1 font-medium"
            wire:loading.attr="disabled"
        >
            <span
                wire:loading
                class="absolute right-2"
            >
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('default.svg.loader', ['class' => 'size-4 animate-spin']);

$__html = app('livewire')->mount($__name, $__params, 'lw-4077209460-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </span>
            <span>Verify Email</span>
        </button>
    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/default/pages/auth/verification-notice.blade.php ENDPATH**/ ?>